# Demo_server_C
Create basic server with C++
- Steps to build the project:
    $ cd Demo_serve_C
    $ make clean
    $ make

- Run the server:
    $ ./server

- Result: the server responsed for 10000 request in 40s (see screenshot result)

