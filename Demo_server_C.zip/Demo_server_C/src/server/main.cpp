#include "server.hpp"

#define SERVER_PORT "8989"

int main() {
    Server server;
    bool is_init = server.Init(SERVER_PORT);
    if (is_init == true)
        server.Run();
    else
        std::cout << "Server init failed" << std::endl;
    return 0;
}
